

c="world"
if print("hi"):
    print("hi")
    print("dei")
else:
    print(c+"world")