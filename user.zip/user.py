name="jothika"
password=2000
Atm_pin=5577
new_name=(input("enter name:"))
new_password=int(input("enter password:"))
new_Atm_pin=int(input("Enter pin:"))
opt=input("1)widhdraw 2)balence enqirey 3)pin change Enter opt:")


if(new_name==name):
    print("user name vaild")
else:
    print("user name invaild")
if int(new_password)==password:
    print("password vaild")
else:
    print("password Invaild")
if int(new_Atm_pin)==Atm_pin:
    print("Atm pin vaild")
else:
    print("Atm Pin Invaild")


