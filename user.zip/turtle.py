# import for turtle
import turtle

# Starting a Working Screen
ws = turtle.Screen()

# initializing a turtle instance
geekyTurtle = turtle.Turtle()

# executing loop 5 times for a star
for i in range(5):

		# moving turtle 100 units forward
		geekyTurtle.forward(100)

		# rotating turtle 144 degree right
		geekyTurtle.right(144)
