import socket
hostname=socket.gethostname()
IpAdd=socket.gethostbyname(hostname)
print("Your Computer Nmae Is:"+hostname)
print("Your Computer Ip Address Is:"+IpAdd)